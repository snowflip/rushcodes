/**********************************************************************
 *<
	FILE: Widget.cpp

	DESCRIPTION:	Appwizard generated plugin

	CREATED BY: 

	HISTORY: 

 *>	Copyright (c) 2000, All Rights Reserved.
 **********************************************************************/

#include "Widget.h"

#define Widget_CLASS_ID	Class_ID(0xd3322b38, 0x7a391793)

#define PBLOCK_REF	0

class Widget : public SimpleObject2 {
	public:
		// Parameter block handled by parent

		//Class vars
		static IObjParam *ip;			//Access to the interface
		// From BaseObject
		CreateMouseCallBack* GetCreateMouseCallBack();
		
		// From Object
		BOOL HasUVW();
		void SetGenUVW(BOOL sw);
		int CanConvertToType(Class_ID obtype);
		Object* ConvertToType(TimeValue t, Class_ID obtype);
		void GetCollapseTypes(Tab<Class_ID> &clist,Tab<TSTR*> &nlist);
		int IntersectRay(TimeValue t, Ray& ray, float& at, Point3& norm);
		//TODO: Evaluate the object and return the ObjectState
		ObjectState Eval(TimeValue t) { return ObjectState(this); };		
		//TODO: Return the validity interval of the object as a whole
		Interval ObjectValidity(TimeValue t) { return FOREVER; }

		// From Animatable
		void BeginEditParams( IObjParam  *ip, ULONG flags,Animatable *prev);
		void EndEditParams( IObjParam *ip, ULONG flags,Animatable *next);

		// From SimpleObject
		void BuildMesh(TimeValue t);
		BOOL OKtoDisplay(TimeValue t);
		void InvalidateUI();

		
		// Loading/Saving
		IOResult Load(ILoad *iload);
		IOResult Save(ISave *isave);

		//From Animatable
		Class_ID ClassID() {return Widget_CLASS_ID;}		
		SClass_ID SuperClassID() { return GEOMOBJECT_CLASS_ID; }
		void GetClassName(TSTR& s) {s = GetString(IDS_CLASS_NAME);}

		RefTargetHandle Clone( RemapDir &remap );

		int	NumParamBlocks() { return 1; }					// return number of ParamBlocks in this instance
		IParamBlock2* GetParamBlock(int i) { return pblock2; } // return i'th ParamBlock
		IParamBlock2* GetParamBlockByID(BlockID id) { return (pblock2->ID() == id) ? pblock2 : NULL; } // return id'd ParamBlock

		void DeleteThis() { delete this; }		
		//Constructor/Destructor

		Widget();
		~Widget();
};



class WidgetClassDesc : public ClassDesc2 {
	public:
	int 			IsPublic() { return TRUE; }
	void *			Create(BOOL loading = FALSE) { return new Widget(); }
	const TCHAR *	ClassName() { return GetString(IDS_CLASS_NAME); }
	SClass_ID		SuperClassID() { return GEOMOBJECT_CLASS_ID; }
	Class_ID		ClassID() { return Widget_CLASS_ID; }
	const TCHAR* 	Category() { return GetString(IDS_CATEGORY); }

	const TCHAR*	InternalName() { return _T("Widget"); }	// returns fixed parsable name (scripter-visible name)
	HINSTANCE		HInstance() { return hInstance; }					// returns owning module handle
	

};

static WidgetClassDesc WidgetDesc;
ClassDesc2* GetWidgetDesc() { return &WidgetDesc; }





enum { widget_params };


//TODO: Add enums for various parameters
enum { 
	widget_size,
	widget_left,
	widget_right
};




static ParamBlockDesc2 widget_param_blk ( widget_params, _T("params"),  0, &WidgetDesc, 
	P_AUTO_CONSTRUCT + P_AUTO_UI, PBLOCK_REF, 
	//rollout
	IDD_PANEL, IDS_PARAMS, 0, 0, NULL,
	// params
	widget_size, 			_T("size"), 		TYPE_FLOAT, 	P_ANIMATABLE, 	IDS_SPIN, 
		p_default, 		0.1f, 
		p_range, 		0.0f,1000.0f, 
		p_ui, 			TYPE_SPINNER,		EDITTYPE_FLOAT, IDC_SIZE_EDIT,	IDC_SIZE_SPIN, 0.01f, 
		end,

	widget_left,        _T("Left"),         TYPE_FLOAT,     P_ANIMATABLE,     IDS_SPIN,
		p_default,         0.0f,
		p_range,         0.0f,100.0f,
		p_ui,             TYPE_SPINNER,        EDITTYPE_UNIVERSE, IDC_LEFT_EDIT,    IDC_LEFT_SPIN, 0.50f,
		end,

	widget_right,        _T("Right"),         TYPE_FLOAT,     P_ANIMATABLE,     IDS_SPIN,
		p_default,         0.0f,
		p_range,         0.0f,100.0f,
		p_ui,             TYPE_SPINNER,        EDITTYPE_UNIVERSE, IDC_RIGHT_EDIT,    IDC_RIGHT_SPIN, 0.50f,
		end,

	end
	);




IObjParam *Widget::ip			= NULL;

//--- Widget -------------------------------------------------------

Widget::Widget()
{
	WidgetDesc.MakeAutoParamBlocks(this);
}

Widget::~Widget()
{
}

IOResult Widget::Load(ILoad *iload)
{
	//TODO: Add code to allow plugin to load its data
	
	return IO_OK;
}

IOResult Widget::Save(ISave *isave)
{
	//TODO: Add code to allow plugin to save its data
	
	return IO_OK;
}

void Widget::BeginEditParams(IObjParam *ip,ULONG flags,Animatable *prev)
{
	this->ip = ip;

	SimpleObject2::BeginEditParams(ip,flags,prev);
	WidgetDesc.BeginEditParams(ip, this, flags, prev);
}

void Widget::EndEditParams( IObjParam *ip, ULONG flags,Animatable *next )
{
	//TODO: Save plugin parameter values into class variables, if they are not hosted in ParamBlocks. 
	

	SimpleObject2::EndEditParams(ip,flags,next);
	WidgetDesc.EndEditParams(ip, this, flags, next);

	this->ip = NULL;
}

//From Object
BOOL Widget::HasUVW() 
{ 
	//TODO: Return whether the object has UVW coordinates or not
	return TRUE; 
}

void Widget::SetGenUVW(BOOL sw) 
{  
	if (sw==HasUVW()) return;
	//TODO: Set the plugin's internal value to sw				
}

//Class for interactive creation of the object using the mouse
class WidgetCreateCallBack : public CreateMouseCallBack 
{
	IPoint2 sp0;		//First point in screen coordinates
	Widget *ob;		//Pointer to the object 
	Point3 p0;			//First point in world coordinates
	Point3 p1;
public:	
	int proc( ViewExp *vpt,int msg, int point, int flags, IPoint2 m, Matrix3& mat);
	void SetObj(Widget *obj) {ob = obj;}
};

int WidgetCreateCallBack::proc(ViewExp *vpt,int msg, int point, int flags, IPoint2 m, Matrix3& mat )
{
	//TODO: Implement the mouse creation code here
	if (msg==MOUSE_POINT||msg==MOUSE_MOVE) 
	{
		switch(point)
		{
		case 0: // only happens with MOUSE_POINT msg
			ob->suspendSnap = TRUE;
			sp0 = m;
			p0 = vpt->SnapPoint(m,m,NULL,SNAP_IN_PLANE);
			mat.SetTrans(p0);
			break;
		case 1:
			{
				ob->suspendSnap = TRUE;
				p1 = vpt->SnapPoint(m,m,NULL,SNAP_IN_PLANE);

				float speedFactor = 24.0f;
				float theSize = (Length(p1 - p0) / speedFactor);

				//Set the overall size in parameter block
				ob->pblock2->SetValue(widget_size, ob->ip->GetTime(), theSize);

				//Invalidate and display the mesh in the viewport
				widget_param_blk.InvalidateUI();
				break;
			}
		case 2:
			{
				return CREATE_STOP;
			}

		}
	}
	else 
	{
		if (msg == MOUSE_ABORT) return CREATE_ABORT;
	}

	return TRUE;
}

static WidgetCreateCallBack WidgetCreateCB;

//From BaseObject
CreateMouseCallBack* Widget::GetCreateMouseCallBack() 
{
	WidgetCreateCB.SetObj(this);
	return(&WidgetCreateCB);
}

//From SimpleObject
void Widget::BuildMesh(TimeValue t)
{
	float size = pblock2->GetFloat(widget_size, t);
	float sizeLeft = pblock2->GetFloat(widget_left, t);
	float sizeRight= pblock2->GetFloat(widget_right, t);
	#include "widgetmesh.h"

	/// ���ݴ�max�л�õ��������㣬���������������ʹ���ܲ�����Ӱ�죩
	/// ���
	mesh.setVert(16,size*Point3(-28.4267-sizeLeft,-12.6976,0.109161));
	mesh.setVert(18,size*Point3(-28.4267-sizeLeft,3.25961,0.109161));
	mesh.setVert(20,size*Point3(-28.4267-sizeLeft,-12.6976,16.2853));
	mesh.setVert(22,size*Point3(-28.4267-sizeLeft,3.25961,16.2853));

	/// �ұ�
	mesh.setVert(9,size*Point3(39.6867+sizeRight,-12.6976,0.109161));
	mesh.setVert(11,size*Point3(39.6867+sizeRight,3.25961,0.109161));
	mesh.setVert(13,size*Point3(39.6867+sizeRight,-12.6976,16.2853));
	mesh.setVert(15,size*Point3(39.6867+sizeRight,3.25961,16.2853));

	mesh.InvalidateGeomCache();

}

BOOL Widget::OKtoDisplay(TimeValue t) 
{
	//TODO: Check whether all the parameters have valid values and return the state
	return TRUE;
}

void Widget::InvalidateUI() 
{
	// Hey! Update the param blocks
}

Object* Widget::ConvertToType(TimeValue t, Class_ID obtype)
{
	//TODO: If the plugin can convert to a nurbs surface then check to see 
	//		whether obtype == EDITABLE_SURF_CLASS_ID and convert the object
	//		to nurbs surface and return the object
	
	return SimpleObject::ConvertToType(t,obtype);
	return NULL;
}

int Widget::CanConvertToType(Class_ID obtype)
{
	//TODO: Check for any additional types the plugin supports
	if (obtype==defObjectClassID ||
		obtype==triObjectClassID) {
		return 1;
	} else {		
	return SimpleObject::CanConvertToType(obtype);
		}
}

// From Object
int Widget::IntersectRay(
		TimeValue t, Ray& ray, float& at, Point3& norm)
{
	//TODO: Return TRUE after you implement this method
	return FALSE;
}

void Widget::GetCollapseTypes(Tab<Class_ID> &clist,Tab<TSTR*> &nlist)
{
    Object::GetCollapseTypes(clist, nlist);
	//TODO: Append any any other collapse type the plugin supports
}

// From ReferenceTarget
RefTargetHandle Widget::Clone(RemapDir& remap) 
{
	Widget* newob = new Widget();	
	//TODO: Make a copy all the data and also clone all the references
	newob->ReplaceReference(0,remap.CloneRef(pblock2));
	newob->ivalid.SetEmpty();
	BaseClone(this, newob, remap);
	return(newob);
}
